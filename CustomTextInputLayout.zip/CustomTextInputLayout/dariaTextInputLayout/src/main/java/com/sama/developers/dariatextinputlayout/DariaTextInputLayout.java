package com.sama.developers.dariatextinputlayout;

import android.content.Context;
import android.content.res.ColorStateList;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class DariaTextInputLayout extends TextInputLayout {
    private TextInputEditText editText;
    private int textColor;
    private int accentColor;
    private int hintColor;
    private int backgroundColor;

    public DariaTextInputLayout(Context context) {
        super(context);
    }

    public DariaTextInputLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public DariaTextInputLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs, defStyleAttr);
    }

    private void init(Context context, AttributeSet attrs, int defStyleAttr) {
        removeAllViews();
        setWillNotDraw(false);
         editText= new TextInputEditText(getContext());
        createEditBox(editText);
        setColors(textColor , accentColor , hintColor , backgroundColor );
    }


    private void createEditBox(TextInputEditText editText) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        editText.setPadding(50,100,100,100);
        editText.setLayoutParams(layoutParams);
    }
    public void setColors( int textColor, int accentColor, int hintColor,int backgroundColor){
        getEditText().setTextColor(textColor);

        getEditText().setBackgroundTintList(ColorStateList.valueOf(backgroundColor));

        //setBoxStrokeColor(hintColor);

    }



}


